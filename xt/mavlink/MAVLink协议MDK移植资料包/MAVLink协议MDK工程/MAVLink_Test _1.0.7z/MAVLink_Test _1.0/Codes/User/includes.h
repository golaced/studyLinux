#ifndef __INCLUDES_H
#define __INCLUDES_H

#include <stdint.h>
#include <stdio.h>
//#include <stdarg.h>  //�ɱ����
#include <ctype.h>
#include <string.h>


#include "stm32f10x.h"
//#include "stm32f10x_it.h"
#include "gpio_conf.h"

/*MAVLink*/


//#include "mavlink_helpers.h"
//#include "checksum.h"
//#include "mavlink_types.h"




/*Driver*/


/*USER*/




#endif /*__INCLUDES_H*/

