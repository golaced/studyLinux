  
MAVLink_STM32
==========================    


## Overview ##
Mavlink c_library code ported to  MDK platform Ver 4.73.0.    


## License ##
You can redistribute the code and/or modify it under terms of the GNU Lesser General Public License.    